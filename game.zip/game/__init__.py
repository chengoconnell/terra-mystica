from __future__ import annotations

from .game import Game

__all__ = ["Game"]
